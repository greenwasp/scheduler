******************************************
Scheduler Project
OS Lab - Fall 2011

Shefali Budhwani
11/08/2011
*******************************************


1) Compile code: javac Scheduler.java
2) Execute: java Scheduler <input-file> verbose
